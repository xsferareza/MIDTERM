<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('customers', 'CustomerController::index');
$routes->get('users', 'UserController::index');
